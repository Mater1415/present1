import 'package:flutter/widgets.dart';

class FFIcons {
  FFIcons._();

  static const String _myFlutterAppFamily = 'MyFlutterApp';

  // MyFlutterApp
  static const IconData kgroup =
      IconData(0xe800, fontFamily: _myFlutterAppFamily);
  static const IconData kfacebookCircled =
      IconData(0xe801, fontFamily: _myFlutterAppFamily);
  static const IconData kgift1 =
      IconData(0xe802, fontFamily: _myFlutterAppFamily);
  static const IconData khealthiconsUiUserProfile =
      IconData(0xe87e, fontFamily: _myFlutterAppFamily);
  static const IconData kicRoundExplore =
      IconData(0xe8ad, fontFamily: _myFlutterAppFamily);
  static const IconData kgroup758530686 =
      IconData(0xe8ae, fontFamily: _myFlutterAppFamily);
  static const IconData kicon2 =
      IconData(0xe8af, fontFamily: _myFlutterAppFamily);
  static const IconData karrowRight =
      IconData(0xe8b1, fontFamily: _myFlutterAppFamily);
  static const IconData kicon1 =
      IconData(0xe8b3, fontFamily: _myFlutterAppFamily);
  static const IconData kicon =
      IconData(0xe8b4, fontFamily: _myFlutterAppFamily);
  static const IconData kfluentMdl2AddFriend =
      IconData(0xe8b6, fontFamily: _myFlutterAppFamily);
  static const IconData kicon3 =
      IconData(0xe8b7, fontFamily: _myFlutterAppFamily);
  static const IconData klocation =
      IconData(0xe8b9, fontFamily: _myFlutterAppFamily);
  static const IconData ktwitterCircled =
      IconData(0xf057, fontFamily: _myFlutterAppFamily);
  static const IconData kgift =
      IconData(0xf06b, fontFamily: _myFlutterAppFamily);
  static const IconData kcalendar =
      IconData(0xf133, fontFamily: _myFlutterAppFamily);
  static const IconData kgoogle =
      IconData(0xf1a0, fontFamily: _myFlutterAppFamily);
  static const IconData ksliders =
      IconData(0xf1de, fontFamily: _myFlutterAppFamily);
}
