import '/components/comment_bottom_sheet/comment_bottom_sheet_widget.dart';
import '/components/present_nav_bar/present_nav_bar_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'demo_widget.dart' show DemoWidget;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DemoModel extends FlutterFlowModel<DemoWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // Model for presentNavBar component.
  late PresentNavBarModel presentNavBarModel;
  // Model for commentBottomSheet component.
  late CommentBottomSheetModel commentBottomSheetModel;

  /// Initialization and disposal methods.

  void initState(BuildContext context) {
    presentNavBarModel = createModel(context, () => PresentNavBarModel());
    commentBottomSheetModel =
        createModel(context, () => CommentBottomSheetModel());
  }

  void dispose() {
    unfocusNode.dispose();
    presentNavBarModel.dispose();
    commentBottomSheetModel.dispose();
  }

  /// Action blocks are added here.

  /// Additional helper methods are added here.
}
