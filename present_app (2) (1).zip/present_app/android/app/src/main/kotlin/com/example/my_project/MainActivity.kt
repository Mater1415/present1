package com.mycompany.presentapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
